# Exercises
https://user-images.githubusercontent.com/70604577/160037789-e5e9b568-c3c8-498a-a89d-90ef57933c9d.mp4

https://user-images.githubusercontent.com/70604577/160037791-441f091f-f9c1-402c-8b16-1186e51d31de.mp4
