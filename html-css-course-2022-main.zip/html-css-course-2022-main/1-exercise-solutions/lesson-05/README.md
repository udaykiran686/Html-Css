# Exercises
![exercises5-1](https://user-images.githubusercontent.com/70604577/160038548-cd23f44e-d572-4441-9f09-9e5b363f4dce.png)
![exercises5-2](https://user-images.githubusercontent.com/70604577/160038556-34f872f8-6c92-45bf-95b2-dda66e117356.png)
